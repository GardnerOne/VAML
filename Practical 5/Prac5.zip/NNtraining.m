function modelNN = NNtraining(images, labels)

modelNN.neighbours=images;
modelNN.labels=labels;

end